<?php $__env->startSection('content'); ?>
<?php
$breadcrumbs = [
['label' => 'Dashboard', 'url' => route('dashboard')],
['label' => 'Users', 'url' => route('users.index')],
];
?>

<?php echo $__env->make('layouts.partials.breadcrumbs', ['breadcrumbs' => $breadcrumbs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-xxl">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>User Management</h2>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#userModal">
                    <i class="bi bi-plus-lg"></i> Add User
                </button>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="">
                <table id="usersTable" class="table table-hover w-100">
                    <thead class="table-light">
                        <tr>
                            <th>S.No.</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Verticals</th>
                            <th>Created At</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr <?php if($user->deleted_at): ?> style="background:#f8d7da;" <?php endif; ?>>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($user->full_name); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td>
                                <span class="badge 
                                    <?php switch($user->role->slug ?? ''):
                                        case ('admin'): ?> bg-danger <?php break; ?>
                                        <?php case ('manager'): ?> bg-primary <?php break; ?>
                                        <?php case ('vm'): ?> bg-info <?php break; ?>
                                        <?php case ('nfo'): ?> bg-warning text-dark <?php break; ?>
                                        <?php default: ?> bg-secondary
                                    <?php endswitch; ?>
                                ">
                                    <?php echo e($user->role->name ?? 'No Role'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($user->verticals && $user->verticals->count()): ?>
                                <?php echo e($user->verticals->pluck('name')->implode(', ')); ?>

                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->created_at->format('M d, Y H:i')); ?></td>
                            <td>
                                <?php if($user->deleted_at): ?>
                                <span class="badge bg-danger">Deleted</span>
                                <?php else: ?>
                                <span class="badge bg-success">Active</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <?php if($user->deleted_at): ?>
                                    <form action="<?php echo e(route('users.restore', $user->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-success btn-sm" type="submit" title="Restore"><i class="bi bi-arrow-counterclockwise"></i></button>
                                    </form>
                                    <?php else: ?>
                                    <button type="button" class="btn btn-primary btn-sm mr-5 editUserBtn" data-user='<?php echo json_encode($user, 15, 512) ?>'><i class="fas fa-pen"></i></button>
                                    <?php if($user->id !== auth()->user()->id && $user->role->slug !== 'manager'): ?>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline" style="margin-left: 4px;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')"><i class="fas fa-trash"></i></button>
                                    </form>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">No users found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- DataTables handles pagination/info -->
        </div>
    </div>
</div>

<div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModalLabel">Create User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(old('user_id') ? url('users/' . old('user_id')) : route('users.store')); ?>" id="userForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo e(old('user_id', '')); ?>">
                    <input type="hidden" name="_method" id="form_method" value="<?php echo e(old('user_id') ? 'PUT' : 'POST'); ?>">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" name="username" value="<?php echo e(old('username')); ?>" required autofocus maxlength="50">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="full_name" name="full_name" value="<?php echo e(old('full_name')); ?>" required maxlength="60">
                        <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3" id="defaultPasswordNote">
                        <span class="text-info small">Default password will be assigned: <b>Welcome@123</b></span>
                    </div>
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Role</label>
                        <select class="form-select <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="role_id" name="role_id" required>
                            <option value="">Select a role</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" data-slug="<?php echo e($role->slug); ?>" <?php echo e(old('role_id') == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3" id="verticalBox" style="display: <?php echo e((old('role_id') && (App\Models\Role::find(old('role_id'))->slug == 'vm' || App\Models\Role::find(old('role_id'))->slug == 'nfo')) ? 'block' : 'none'); ?>;">
                        <label for="vertical_ids" class="form-label">Verticals</label>
                        <select name="vertical_ids[]" id="vertical_ids" class="form-control" multiple>
                            <?php $__currentLoopData = $verticals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vertical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vertical->id); ?>" <?php echo e(collect(old('vertical_ids', []))->contains($vertical->id) ? 'selected' : ''); ?>><?php echo e($vertical->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['vertical_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</small>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary" id="userSubmitBtn">
                            <span id="userBtnText"><?php echo e(old('user_id') ? 'Update' : 'Create'); ?></span>
                            <span id="userBtnSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        </button>
                    </div>
                </form>
                <div id="formErrors" class="alert alert-danger mt-3 d-none">
                    <ul class="mb-0" id="formErrorsList"></ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
<style>
    /* Right-align DataTables pagination */
    div.dataTables_wrapper div.dataTables_paginate {
        text-align: right !important;
        float: right !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#usersTable').DataTable({
            responsive: true,
            dom: '<"d-flex justify-content-between align-items-center mb-2"Bfl>rtip',
        buttons: [
            {
                    extend: 'copy',
                    text: '<i class="bi bi-clipboard"></i>',
                    className: 'btn btn-light btn-sm me-1',
                    titleAttr: 'Copy'
                },
                {
                    extend: 'csv',
                    text: '<i class="bi bi-filetype-csv"></i>',
                    className: 'btn btn-light btn-sm me-1',
                    titleAttr: 'Export as CSV'
                },
                {
                    extend: 'excel',
                    text: '<i class="bi bi-file-earmark-excel"></i>',
                    className: 'btn btn-light btn-sm me-1',
                    titleAttr: 'Export as Excel'
                },
                {
                    extend: 'pdf',
                    text: '<i class="bi bi-file-earmark-pdf"></i>',
                    className: 'btn btn-light btn-sm me-1',
                    titleAttr: 'Export as PDF'
                },
                {
                    extend: 'print',
                    text: '<i class="bi bi-printer"></i>',
                    className: 'btn btn-light btn-sm',
                    titleAttr: 'Print'
                }
            ]
        });

        // Password validation for Create/Edit User Modal
        $('#userForm').on('submit', function(e) {
            var isEdit = $('#user_id').val() !== '';
            if (isEdit) {
                var password = $('#password').val();
                var pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{6,}$/;
                if (password && !pattern.test(password)) {
                    alert('Password must be at least 6 characters, contain one uppercase letter, one lowercase letter, one digit, and one special character (!@#$%^&*).');
                    $('#password').focus();
                    e.preventDefault();
                    return false;
                }
            }
        });

        // Show modal for create
        $(document).on('click', '[data-bs-target="#userModal"]', function() {
            clearUserForm();
            $('#userModalLabel').text('Create User');
            $('#userBtnText').text('Create');
        $('#userForm').attr('action', '<?php echo e(route('users.store')); ?>');
            $('#form_method').val('POST');
            $('#user_id').val('');
            $('#defaultPasswordNote').show();
            $('#formErrors').addClass('d-none');
        });

        // Show modal for edit
        $(document).on('click', '.editUserBtn', function() {
            var user = $(this).data('user');
            clearUserForm();
            $('#userModal').modal('show');
            $('#userModalLabel').text('Edit User');
            $('#userBtnText').text('Update');
            $('#userForm').attr('action', '/users/' + user.id);
            $('#form_method').val('PUT');
            $('#user_id').val(user.id);
            $('#username').val(user.username);
            $('#full_name').val(user.full_name);
            $('#role_id').val(user.role_id);
            $('#defaultPasswordNote').hide();
            $('#password').removeAttr('required');
            $('#passwordHelpText').text(' (leave blank to keep current)');
            // Set verticals
            if (user.verticals && user.verticals.length > 0) {
            var verticalIds = user.verticals.map(function(v) { return v.id; });
                $('#vertical_ids').val(verticalIds);
            } else {
                $('#vertical_ids').val([]);
            }
            $('#vertical_ids').trigger('change');
            // Show/hide vertical box based on role slug
            var selectedRoleSlug = $('#role_id option:selected').data('slug');
            if (selectedRoleSlug === 'vm' || selectedRoleSlug === 'nfo') {
                $('#verticalBox').show();
            } else {
                $('#verticalBox').hide();
            }
            $('#formErrors').addClass('d-none');
        });

        // Role change show/hide verticals (use slug)
        $('#role_id').on('change', function() {
            var selectedRoleSlug = $('#role_id option:selected').data('slug');
            if (selectedRoleSlug === 'vm' || selectedRoleSlug === 'nfo') {
                $('#verticalBox').show();
            } else {
                $('#verticalBox').hide();
                $('#vertical_ids').val([]).trigger('change');
            }
        });

        // Clear form on modal close
        $('#userModal').on('hidden.bs.modal', function () {
            clearUserForm();
        });

        function clearUserForm() {
            $('#userForm')[0].reset();
            $('#user_id').val('');
            $('#form_method').val('POST');
        $('#userForm').attr('action', '<?php echo e(route('users.store')); ?>');
            $('#userBtnText').text('Create');
            $('#userModalLabel').text('Create User');
            $('#defaultPasswordNote').show();
            $('#formErrors').addClass('d-none');
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tms-live\resources\views/users/index.blade.php ENDPATH**/ ?>