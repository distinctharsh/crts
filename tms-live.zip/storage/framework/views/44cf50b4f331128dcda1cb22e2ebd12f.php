<style>
.timeline-vertical {
  position: relative;
  margin: 0;
  padding: 0;
  max-height: 400px;
  overflow-y: auto;
}
/* Hide scrollbar when not needed (Webkit browsers) */
.timeline-vertical::-webkit-scrollbar {
  width: 8px;
  background: transparent;
}
.timeline-vertical:has(> *:only-child)::-webkit-scrollbar {
  display: none;
}
/* Hide scrollbar when not needed (Firefox) */
.timeline-vertical {
  scrollbar-width: thin;
  scrollbar-color: #bbb #f8fafc;
}
.timeline-vertical:not(:hover)::-webkit-scrollbar-thumb {
  background: #eee;
}
/* Hide scrollbar if not overflowing */
.timeline-vertical:not(:hover):not(:active)::-webkit-scrollbar-thumb {
  background: transparent;
}
.timeline-vertical-line {
  position: absolute;
  left: 24px;
  top: 0;
  width: 4px;
  height: 100vh;
  background: #e0e0e0;
  border-radius: 2px;
  z-index: 0;
}
.timeline-vertical-item {
  position: relative;
  margin-left: 60px;
  margin-bottom: 28px;
  padding-left: 0;
}
.timeline-vertical-dot {
  position: absolute;
  left: -44px;
  top: 12px;
  width: 20px;
  height: 20px;
  background: #fff;
  border: 4px solid #0d6efd;
  border-radius: 50%;
  z-index: 2;
}
.timeline-vertical-item.pending_with_user .timeline-vertical-dot,
.timeline-vertical-item.pending_with_vendor .timeline-vertical-dot {
  border-color: #dc3545;
}
.timeline-vertical-content {
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  padding: 12px 18px;
  border-left: 4px solid #0d6efd;
}
.timeline-vertical-item.pending_with_user .timeline-vertical-content,
.timeline-vertical-item.pending_with_vendor .timeline-vertical-content {
  border-left-color: #dc3545;
}
</style>
<div class="card shadow-sm mb-4">
  <div class="card-header bg-light">
    <h5 class="mb-0">Status History</h5>
  </div>
  <div class="card-body position-relative">
    <div class="timeline-vertical">
      <div class="timeline-vertical-line"></div>
      <?php $__currentLoopData = $complaint->actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $assignedUser = $action->assigned_to ? \App\Models\User::find($action->assigned_to) : null;
          $statusName = $action->status ? $action->status->name : null;
        ?>
        <div class="timeline-vertical-item <?php echo e($statusName); ?>">
          <span class="timeline-vertical-dot"></span>
          <div class="timeline-vertical-content">
            
            <div class="mb-1">
              <?php
                $colorClass = $action->status && $action->status->color ? 'bg-' . $action->status->color : 'bg-secondary';
              ?>
              <span class="badge <?php echo e($colorClass); ?>">
                <?php echo e(ucfirst($action->status->display_name ?? $statusName)); ?>

              </span>
            </div>
            
            <?php if(in_array($statusName, ['assigned', 'reassigned', 'reverted']) && $action->assigned_to): ?>
              <div class="text-muted small mb-1">
                <span class="fw-semibold"><?php echo e($statusName === 'reverted' ? 'Reverted To:' : 'Assigned To:'); ?></span>
                <?php echo e($assignedUser ? $assignedUser->full_name : 'Unknown User'); ?>

                <?php if($assignedUser && $assignedUser->role): ?>
                  (<?php echo e(strtoupper($assignedUser->role->slug)); ?>)
                <?php endif; ?>
              </div>
            <?php endif; ?>
            
            <?php if($action->description): ?>
              <div class="mb-1 p-2 bg-light border rounded fst-italic">
                <?php echo e($action->description); ?>

              </div>
            <?php endif; ?>
            
            <?php if(!in_array($statusName, ['assigned', 'reassigned', 'reverted'])): ?>
              <div class="mb-1 fw-bold d-flex align-items-center">
                <i class="bi bi-person-circle me-2"></i>
                <?php echo e($action->user && $action->user_id != 0 ? $action->user->full_name : 'Guest User'); ?>

              </div>
            <?php endif; ?>
            
            <?php if(in_array($statusName, ['assigned', 'reassigned', 'reverted'])): ?>
              <div class="text-muted small mb-1">
                <span class="fw-semibold"><?php echo e($statusName === 'reverted' ? 'Reverted By:' : 'Assigned By:'); ?></span>
                <?php echo e($action->user && $action->user_id != 0 ? $action->user->full_name : 'Guest User'); ?>

              </div>
            <?php endif; ?>
            
            <div class="text-muted small mb-1">
              <i class="bi bi-clock me-1"></i> <?php echo e($action->created_at->format('M d, Y h:i A')); ?>

            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\tms-live\resources\views/complaints/partials/timeline.blade.php ENDPATH**/ ?>