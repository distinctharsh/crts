<?php $__env->startSection('content'); ?>
<?php
    function getTextColor($bgColor) {
        $bgColor = ltrim($bgColor, '#');
        $r = hexdec(substr($bgColor, 0, 2));
        $g = hexdec(substr($bgColor, 2, 2));
        $b = hexdec(substr($bgColor, 4, 2));
        return (($r * 299 + $g * 587 + $b * 114) / 1000) > 128 ? '#222' : '#fff';
    }
?>
<div class="container py-4">
    <h2 class="fw-bold mb-4 text-center">Master Management</h2>
    <ul class="nav nav-tabs mb-3" id="masterTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="network-types-tab" data-bs-toggle="tab" data-bs-target="#network-types" type="button" role="tab">Network Types</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="sections-tab" data-bs-toggle="tab" data-bs-target="#sections" type="button" role="tab">Sections</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="statuses-tab" data-bs-toggle="tab" data-bs-target="#statuses" type="button" role="tab">Status</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="verticals-tab" data-bs-toggle="tab" data-bs-target="#verticals" type="button" role="tab">Verticals</button>
        </li>
    </ul>
    <div class="tab-content" id="masterTabsContent">
        <!-- Network Types Tab -->
        <div class="tab-pane fade show active" id="network-types" role="tabpanel">
            <div class="card mb-4 shadow rounded-4 border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white rounded-top-4">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-network-wired me-2"></i>Network Types</h5>
                    <button class="btn btn-light btn-sm fw-semibold px-3 py-1" data-bs-toggle="modal" data-bs-target="#addNetworkTypeModal"><i class="fas fa-plus"></i> </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Name</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $networkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $networkType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($networkType->name); ?></td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-outline-primary btn-sm me-1" data-bs-toggle="tooltip" title="Edit" data-bs-target="#editNetworkTypeModal<?php echo e($networkType->id); ?>" data-bs-toggle2="modal" onclick="$('#editNetworkTypeModal<?php echo e($networkType->id); ?>').modal('show')"><i class="fas fa-pen"></i></button>
                                    <button class="btn btn-outline-danger btn-sm" data-bs-toggle="tooltip" title="Delete" data-bs-target="#deleteNetworkTypeModal<?php echo e($networkType->id); ?>" data-bs-toggle2="modal" onclick="$('#deleteNetworkTypeModal<?php echo e($networkType->id); ?>').modal('show')"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <!-- Edit Modal for this NetworkType -->
                            <div class="modal fade" id="editNetworkTypeModal<?php echo e($networkType->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.network-types.update', $networkType)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header bg-primary text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-pen me-2"></i>Edit Network Type</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Name</label>
                                                    <input type="text" name="name" class="form-control tom-select" value="<?php echo e($networkType->name); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Delete Modal for this NetworkType -->
                            <div class="modal fade" id="deleteNetworkTypeModal<?php echo e($networkType->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.network-types.destroy', $networkType)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-header bg-danger text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Delete Network Type</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="mb-0">Are you sure you want to delete <strong><?php echo e($networkType->name); ?></strong>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Yes, Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted">No Network Types found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sections Tab -->
        <div class="tab-pane fade" id="sections" role="tabpanel">
            <div class="card mb-4 shadow rounded-4 border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-success text-white rounded-top-4">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-layer-group me-2"></i>Sections</h5>
                    <button class="btn btn-light btn-sm fw-semibold px-3 py-1" data-bs-toggle="modal" data-bs-target="#addSectionModal"><i class="fas fa-plus"></i> </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Name</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($section->name); ?></td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-outline-success btn-sm me-1" data-bs-toggle="tooltip" title="Edit" data-bs-target="#editSectionModal<?php echo e($section->id); ?>" onclick="$('#editSectionModal<?php echo e($section->id); ?>').modal('show')"><i class="fas fa-pen"></i></button>
                                    <button class="btn btn-outline-danger btn-sm" data-bs-toggle="tooltip" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteSectionModal<?php echo e($section->id); ?>" data-bs-toggle2="modal" onclick="$('#deleteSectionModal<?php echo e($section->id); ?>').modal('show')"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <!-- Edit Modal for this Section -->
                            <div class="modal fade" id="editSectionModal<?php echo e($section->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.sections.update', $section)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header bg-success text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-pen me-2"></i>Edit Section</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Name</label>
                                                    <input type="text" name="name" class="form-control tom-select" value="<?php echo e($section->name); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-success">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Delete Modal for this Section -->
                            <div class="modal fade" id="deleteSectionModal<?php echo e($section->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.sections.destroy', $section)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-header bg-danger text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Delete Section</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="mb-0">Are you sure you want to delete <strong><?php echo e($section->name); ?></strong>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Yes, Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted">No Sections found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Statuses Tab -->
        <div class="tab-pane fade" id="statuses" role="tabpanel">
            <div class="card mb-4 shadow rounded-4 border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-info text-white rounded-top-4">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-flag me-2"></i>Status</h5>
                    <button class="btn btn-light btn-sm fw-semibold px-3 py-1" data-bs-toggle="modal" data-bs-target="#addStatusModal"><i class="fas fa-plus"></i> </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Name</th>
                                <th>Color</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($status->display_name); ?></td>
                                <td>
                                    <span class="badge px-3 py-2 bg-<?php echo e($status->color); ?>">
                                        <?php echo e($status->color); ?>

                                    </span>
                                </td>

                                <td class="text-end pe-4">
                                    <button class="btn btn-outline-info btn-sm me-1" data-bs-toggle="tooltip" title="Edit" data-bs-target="#editStatusModal<?php echo e($status->id); ?>" onclick="$('#editStatusModal<?php echo e($status->id); ?>').modal('show')"><i class="fas fa-pen"></i></button>
                                    <button class="btn btn-outline-danger btn-sm" data-bs-toggle="tooltip" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteStatusModal<?php echo e($status->id); ?>" data-bs-toggle2="modal" onclick="$('#deleteStatusModal<?php echo e($status->id); ?>').modal('show')"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <!-- Edit Modal for this Status -->
                            <div class="modal fade" id="editStatusModal<?php echo e($status->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.statuses.update', $status)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header bg-info text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-pen me-2"></i>Edit Status</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Name</label>
                                                    <input type="text" name="name" class="form-control tom-select" value="<?php echo e($status->name); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Color</label>
                                                    <select name="color" class="form-select" required>
                                                        <option value="primary" <?php echo e($status->color == 'primary' ? 'selected' : ''); ?>>Primary</option>
                                                        <option value="secondary" <?php echo e($status->color == 'secondary' ? 'selected' : ''); ?>>Secondary</option>
                                                        <option value="success" <?php echo e($status->color == 'success' ? 'selected' : ''); ?>>Success</option>
                                                        <option value="danger" <?php echo e($status->color == 'danger' ? 'selected' : ''); ?>>Danger</option>
                                                        <option value="warning" <?php echo e($status->color == 'warning' ? 'selected' : ''); ?>>Warning</option>
                                                        <option value="info" <?php echo e($status->color == 'info' ? 'selected' : ''); ?>>Info</option>
                                                        <option value="light" <?php echo e($status->color == 'light' ? 'selected' : ''); ?>>Light</option>
                                                        <option value="dark" <?php echo e($status->color == 'dark' ? 'selected' : ''); ?>>Dark</option>
                                                    </select>
                                                </div>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" name="visible_to_user" id="visible_to_user_<?php echo e($status->id); ?>" value="1" <?php echo e($status->visible_to_user ? 'checked' : ''); ?>>
                                                    <label class="form-check-label" for="visible_to_user_<?php echo e($status->id); ?>">
                                                        Show to user in status dropdown?
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-info">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Delete Modal for this Status -->
                            <div class="modal fade" id="deleteStatusModal<?php echo e($status->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.statuses.destroy', $status)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-header bg-danger text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Delete Status</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="mb-0">Are you sure you want to delete <strong><?php echo e($status->name); ?></strong>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Yes, Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted">No Status found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Verticals Tab -->
        <div class="tab-pane fade" id="verticals" role="tabpanel">
            <div class="card mb-4 shadow rounded-4 border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-warning text-dark rounded-top-4">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-building me-2"></i>Verticals</h5>
                    <button class="btn btn-light btn-sm fw-semibold px-3 py-1" data-bs-toggle="modal" data-bs-target="#addVerticalModal"><i class="fas fa-plus"></i> </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Name</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $verticals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vertical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($vertical->name); ?></td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-outline-warning btn-sm me-1" data-bs-toggle="tooltip" title="Edit" data-bs-target="#editVerticalModal<?php echo e($vertical->id); ?>" onclick="$('#editVerticalModal<?php echo e($vertical->id); ?>').modal('show')"><i class="fas fa-pen"></i></button>
                                    <button class="btn btn-outline-danger btn-sm" data-bs-toggle="tooltip" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteVerticalModal<?php echo e($vertical->id); ?>" data-bs-toggle2="modal" onclick="$('#deleteVerticalModal<?php echo e($vertical->id); ?>').modal('show')"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <!-- Edit Modal for this Vertical -->
                            <div class="modal fade" id="editVerticalModal<?php echo e($vertical->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.verticals.update', $vertical)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header bg-warning text-dark rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-pen me-2"></i>Edit Vertical</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Name</label>
                                                    <input type="text" name="name" class="form-control tom-select" value="<?php echo e($vertical->name); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-warning">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Delete Modal for this Vertical -->
                            <div class="modal fade" id="deleteVerticalModal<?php echo e($vertical->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4">
                                        <form action="<?php echo e(route('masters.verticals.destroy', $vertical)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-header bg-danger text-white rounded-top-4">
                                                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Delete Vertical</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="mb-0">Are you sure you want to delete <strong><?php echo e($vertical->name); ?></strong>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-danger">Yes, Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted">No Verticals found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals for Add/Edit (one for each master, can be reused for edit) -->
    <!-- Network Type Modals -->
    <div class="modal fade" id="addNetworkTypeModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content rounded-4">
                <form action="<?php echo e(route('masters.network-types.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-primary text-white rounded-top-4">
                        <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Add Network Type</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editNetworkTypeModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Network Type</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Section Modals -->
    <div class="modal fade" id="addSectionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                  <form action="<?php echo e(route('masters.sections.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Add Section</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editSectionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Section</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Status Modals -->
    <div class="modal fade" id="addStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('masters.statuses.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Add Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control tom-select" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Color</label>
                            <select name="color" class="form-select" required>
                                <option value="primary">Primary</option>
                                <option value="secondary">Secondary</option>
                                <option value="success">Success</option>
                                <option value="danger">Danger</option>
                                <option value="warning">Warning</option>
                                <option value="info">Info</option>
                                <option value="light">Light</option>
                                <option value="dark">Dark</option>
                            </select>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="visible_to_user" id="visible_to_user_new" value="1" checked>
                            <label class="form-check-label" for="visible_to_user_new">
                                Show to user in status dropdown?
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control tom-select" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Color</label>
                            <input type="color" class="form-control form-control-color" value="#0d6efd" title="Choose color">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Vertical Modals -->
    <div class="modal fade" id="addVerticalModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('masters.verticals.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Add Vertical</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editVerticalModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                  <form action="<?php echo e(route('masters.verticals.update', $vertical)); ?>"  method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Vertical</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control tom-select" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Enable Bootstrap tooltips
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.forEach(function (tooltipTriggerEl) {
            new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('select.tom-select').forEach(function(el) {
            new TomSelect(el, {
                create: false,
                sortField: {
                    field: 'text',
                    direction: 'asc'
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tms-live\resources\views/masters/index.blade.php ENDPATH**/ ?>