<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Dashboard</h4>
                    <!-- <div>
                        <?php if(auth()->user()->isManager() || auth()->user()->isVM()): ?>
                        <a href="<?php echo e(route('complaints.index')); ?>" class="btn btn-primary">View All Complaints</a>
                        <?php endif; ?>
                    </div> -->
                </div>

                <div class="card-body">
                    <!-- Welcome Message -->
                    <div class="alert alert-info">
                        Welcome back, <?php echo e(auth()->user()->name); ?>!
                        <?php if(auth()->user()->isManager()): ?>
                        As a Manager, you can view and assign all complaints.
                        <?php elseif(auth()->user()->isVM()): ?>
                        As a Vendor Manager, you can self-assign complaints and assign them to NFOs.
                        <?php elseif(auth()->user()->isNFO()): ?>
                        As a Network Field Officer, you can resolve complaints and reassign them.
                        <?php endif; ?>
                    </div>

                    <!-- Statistics (from controller variables) -->
                    <div class="row justify-content-center mb-4">
                        <div class="col-12 mb-4">
                            <div class="row g-4">
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('complaints.index')); ?>" class="card-link-stretched text-decoration-none">
                                        <div class="card shadow-lg border-0 rounded-4 bg-primary text-white h-100 clickable-card">
                                            <div class="card-body text-center py-4">
                                                <h5 class="card-title mb-2">Total Tickets</h5>
                                                <h2 class="fw-bold mb-0 display-5"><?php echo e($totalComplaints); ?></h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php if(!auth()->user()->isNFO()): ?>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('complaints.index', ['status' => $unassignedStatusId ?? ''])); ?>" class="card-link-stretched text-decoration-none">
                                        <div class="card shadow-lg border-0 rounded-4 bg-warning text-dark h-100 clickable-card">
                                            <div class="card-body text-center py-4">
                                                <h5 class="card-title mb-2">Unassigned</h5>
                                                <h2 class="fw-bold mb-0 display-5"><?php echo e($unassignedComplaints); ?></h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php endif; ?>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('complaints.index', ['status' => $completedStatusId ?? ''])); ?>" class="card-link-stretched text-decoration-none">
                                        <div class="card shadow-lg border-0 rounded-4 bg-success text-white h-100 clickable-card">
                                            <div class="card-body text-center py-4">
                                                <h5 class="card-title mb-2">Completed</h5>
                                                <h2 class="fw-bold mb-0 display-5"><?php echo e($completedComplaints); ?></h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('complaints.index', ['assigned_to_me' => 1])); ?>" class="card-link-stretched text-decoration-none">
                                        <div class="card shadow-lg border-0 rounded-4 bg-info text-white h-100 clickable-card">
                                            <div class="card-body text-center py-4">
                                                <h5 class="card-title mb-2">Assign to Me</h5>
                                                <h2 class="fw-bold mb-0 display-5"><?php echo e($assignToMeComplaints); ?></h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Today's Complaints -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card shadow-lg border-0 rounded-4 mt-2">
                                <div class="card-header bg-gradient-primary text-white rounded-top-4 d-flex align-items-center justify-content-between" style="background: linear-gradient(90deg, #0d6efd 0%, #0a58ca 100%);">
                                    <h4 class="mb-0">Today's Tickets</h4>
                                    <span class="badge bg-light text-primary fs-6"><?php echo e($todayComplaints->count()); ?> Today</span>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="complaintsTable" class="table table-hover table-bordered table-striped align-middle w-100">
                                            <thead class="table-primary">
                                                <tr>
                                                    <th class="no-sort">S.No.</th>
                                                    <th>Reference</th>
                                                    <th>User</th>
                                                    <th>Section</th>
                                                    <th>Network</th>
                                                    <th>Vertical</th>
                                                    <th>Status</th>
                                                    <th>Priority</th>
                                                    <th>Assigned To</th>
                                                    <th>Description</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $todayComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($complaint->reference_number); ?></td>
                                                    <td><?php echo e($complaint->user_name  ?? '-'); ?></td>
                                                    <td><?php echo e($complaint->section  ? $complaint->section->name : ''); ?></td>
                                                    <td><?php echo e($complaint->networkType?->name ?? 'N/A'); ?></td>
                                                    <td><?php echo e($complaint->vertical?->name ?? 'N/A'); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php echo e($complaint->status_color); ?>">
                                                            <?php echo e($complaint->status?->display_name ?? 'Unknown'); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php echo e($complaint->priority_color ?? 'secondary'); ?>">
                                                            <?php echo e(ucfirst($complaint->priority) ?? 'Unknown'); ?>

                                                        </span>
                                                    </td>
                                                    <td><?php echo e($complaint->assignedTo?->full_name ?? 'Not Assigned'); ?></td>
                                                    <!-- <td>
                                                        <?php $assignedBy = $complaint->assigned_by ? \App\Models\User::find($complaint->assigned_by) : null; ?>
                                                        <?php echo e($assignedBy?->full_name ?? 'N/A'); ?>

                                                    </td> -->
                                                      <td>
                                                        <div style="white-space: pre-wrap; word-break: break-word; max-width: 300px;">
                                                            <?php echo e($complaint->description ?? 'Unknown'); ?>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('complaints.show', $complaint)); ?>" class="btn btn-sm btn-primary">View</a>
                                                        <?php if(auth()->guard()->check()): ?>
                                                        <?php if((auth()->user()->isManager() || auth()->user()->isVM()) && (!$complaint->assigned_to || $complaint->assigned_to == 0) && $complaint->status->name != 'completed' && $complaint->status->name != 'closed'): ?>
                                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#assignModal<?php echo e($complaint->id); ?>">
                                                            Assign
                                                        </button>
                                                        <?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="10" class="text-center">No complaints today.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <!-- Render all assign modals after the table for DataTables compatibility -->
                                        <?php $__currentLoopData = $todayComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if((auth()->user()->isManager() || auth()->user()->isVM()) && (!$complaint->assigned_to || $complaint->assigned_to == 0) && $complaint->status->name != 'completed' && $complaint->status->name != 'closed'): ?>
                                        <div class="modal fade" id="assignModal<?php echo e($complaint->id); ?>" tabindex="-1" aria-labelledby="assignModalLabel<?php echo e($complaint->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form action="<?php echo e(route('complaints.assign', $complaint)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="assignModalLabel<?php echo e($complaint->id); ?>">Assign Ticket <?php echo e($complaint->reference_number); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="assigned_to<?php echo e($complaint->id); ?>" class="form-label">Assign To</label>
                                                                <select class="form-select" name="assigned_to" id="assigned_to<?php echo e($complaint->id); ?>" required>
                                                                    <option value="">Select User</option>
                                                                    <?php $__currentLoopData = $complaint->assignableUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->full_name); ?> (<?php echo e(strtoupper($user->role->name)); ?>)</option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="description<?php echo e($complaint->id); ?>" class="form-label">Remarks</label>
                                                                <textarea class="form-control" name="description" id="description<?php echo e($complaint->id); ?>" rows="3"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Assign</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/buttons.bootstrap5.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap5.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <!-- Removed duplicate jQuery -->
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/responsive.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('#complaintsTable').DataTable({
            responsive: false, // Disable responsive extension
            scrollX: true,     // Enable horizontal scrolling
            order: [
                [1, 'desc']
            ], // Reference column descending
            pageLength: 10,
            lengthMenu: [
                [10, 15, 20, 50, 100, -1],
                [10, 15, 20, 50, 100, 'All']
            ],
            language: {
                search: "",
                searchPlaceholder: "Search complaints..."
            },
            dom: 'lfrtip',
            columnDefs: [{
                    orderable: false,
                    targets: 0
                } // Disable sorting on S.No.
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .bg-gradient-primary {
        background: linear-gradient(90deg, #0d6efd 0%, #0a58ca 100%) !important;
        color: #fff !important;
    }

    .card {
        border-radius: 22px;
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.13);
        border: none;
        margin-bottom: 2rem;
        transition: box-shadow 0.2s;
    }

    .card-header {
        border-radius: 22px 22px 0 0;
        font-weight: 700;
        font-size: 1.18rem;
        letter-spacing: 0.7px;
        box-shadow: 0 2px 8px rgba(13, 110, 253, 0.07);
    }

    .table-primary {
        background: linear-gradient(90deg, #0d6efd 0%, #0a58ca 100%) !important;
        color: #fff !important;
        font-size: 1.08rem;
        letter-spacing: 0.5px;
    }

    .table-bordered {
        border-radius: 14px;
        overflow: hidden;
    }

    .table-hover tbody tr:hover {
        background: #f0f6ff !important;
        transition: background 0.2s;
    }

    .card-link-stretched {
        text-decoration: none;
        display: block;
    }

    .clickable-card {
        cursor: pointer;
        transition: transform 0.12s, box-shadow 0.12s;
    }

    .clickable-card:hover,
    .clickable-card:focus {
        transform: translateY(-4px) scale(1.03);
        box-shadow: 0 12px 36px 0 rgba(31, 38, 135, 0.18);
        z-index: 2;
        text-decoration: none;
    }

    /* Modern Table Enhancements */
    .table-responsive {
        border-radius: 16px;
        box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        overflow-x: auto;
        background: #fff;
        margin-bottom: 1.5rem;
    }

    #complaintsTable {
        min-width: 1200px;
        border-radius: 12px;
        overflow: hidden;
    }

    #complaintsTable thead th {
        position: sticky;
        top: 0;
        background: linear-gradient(90deg, #0d6efd 0%, #0a58ca 100%) !important;
        color: #fff !important;
        z-index: 2;
    }

    #complaintsTable tbody tr:hover {
        background: #eaf1fb !important;
        transition: background 0.2s;
    }

    .table-responsive::-webkit-scrollbar {
        height: 8px;
    }
    .table-responsive::-webkit-scrollbar-thumb {
        background: #0d6efd;
        border-radius: 4px;
    }
    .table-responsive::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tms-live\resources\views/dashboard.blade.php ENDPATH**/ ?>